var map, mouseDownX =0,mouseDownY = 0;

//let nominatimSearch ="https://nominatim.openstreetmap.org/search?polygon_geojson=1&accept-language=ru&format=json&q=";
//let nominatimReverse="https://nominatim.openstreetmap.org/reverse?polygon_geojson=1&accept-language=ru&format=json";
//let nominatimDetails="https://nominatim.openstreetmap.org/ui/details.html";
//let tilePattern = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';

let nominatimReverse="http://map.mchs.lnr/nominatim/reverse.php?polygon_geojson=1&accept-language=ru&format=json";
let nominatimDetails="http://map.mchs.lnr/dist/details.html";
let tilePattern = 'http://map.mchs.lnr/hot/{z}/{x}/{y}.png';
let nominatimSearch ="http://map.mchs.lnr/nominatim/search.php?polygon_geojson=1&accept-language=ru&format=json&q=";
let routeApi ="http://map.mchs.lnr:5000";
let instructionServer = "http://map.mchs.lnr:8080";
let searchBlockPrefab,routeItemPrefab, instructionPrefab;
let results = [];
let lastObj = null, instructionObj = null;
let routeMapObjects= [];
let fromMarker = null, toMarker = null;
let routes = [], instructions = [];
let seletedRouteInx = null;


function focus(el){
	if(lastObj != null)
		lastObj.removeFrom(map);
	
	lastObj = L.geoJSON(el.geojson, {
    style: function (feature) {
        return {color: "#0000FF"};
    }
	}).bindPopup(function (layer) {
		return el.display_name;
	}).addTo(map);
	
	
	map.fitBounds(lastObj.getBounds());
}
function search(text,excluded = ""){
	if(text == ""){
		showMsg("Введите текст для поиска!");
		return;
	}
	
	let url = nominatimSearch+text;
	if(excluded !="")
		url+="&exclude_place_ids="+excluded;
	$.ajax({
	  url: url
	}).done(function(data) {
		if(typeof(data) != "object"){
			showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
			return;
		}
		if(data.length == 0){
			showMsg("Ничего не найдено!",2000)
			return;
		}
		results = data;
		if(lastObj != null)
			lastObj.removeFrom(map);
		$("#searchResults").html("");
		$(".searchCounter").html("Найдено результатов: "+data.length);
		let excs = excluded.split(",");
		for(let i = 0 ;i < data.length;i++){			
			excs.push(data[i].place_id);
			let el = $(searchBlockPrefab).clone();
			$(el).attr("data-inx",i);
			$(el).find(".sName").html(data[i].display_name);
			$(el).find("img").attr("src",data[i].icon);
			$(el).find("a").attr("href",`${nominatimDetails}?osmtype=${data[i].osm_type[0].toUpperCase()}&osmid=${data[i].osm_id}&class=${data.class?data.class:""}`);					
			$("#searchResults").append(el);
			
			
			$(el).find(".linkFrom").on("click",function(e){
				let data = results[$(e.currentTarget).closest(".searchBlock").attr("data-inx")];
				
				$("#routeFromField").val(data.display_name);
				$("#routeFromField").attr("data-lon",data.lon);
				$("#routeFromField").attr("data-lat",data.lat);
				
				if(fromMarker != null)
					fromMarker.removeFrom(map);
				fromMarker = L.marker([data.lat, data.lon]).bindPopup(function (layer) {
					return data.display_name;
				}).addTo(map);
				fromMarker._icon.classList.add("greenMarker");
				
				updateRoutes();					
				map.setView(fromMarker.getLatLng(),14);
				if($("#routeResultsWrapper").css("display") == "none")
					$("#openRouters").trigger("click");
			});
			$(el).find(".linkTo").on("click",function(e){
				let data = results[$(e.currentTarget).closest(".searchBlock").attr("data-inx")];
				
				$("#routeToField").val(data.display_name);
				$("#routeToField").attr("data-lon",data.lon);
				$("#routeToField").attr("data-lat",data.lat);
				
				if(toMarker != null)
					toMarker.removeFrom(map);
				
				toMarker= L.marker([data.lat, data.lon]).bindPopup(function (layer) {
					return data.display_name;
				}).addTo(map);
				toMarker._icon.classList.add("redMarker");
				
				updateRoutes();					
				map.setView(toMarker.getLatLng(),14);
				if($("#routeResultsWrapper").css("display") == "none")
					$("#openRouters").trigger("click");
				
			});
			$(el).on("click",function(e){
				if(!$(e.target).is(".linkDetail") && !$(e.target).is(".linkFrom") && !$(e.target).is(".linkTo")&& !$(e.target).is(".fa-map-marker-alt")&& !$(e.target).is(".fa-circle")){
					$("#searchResults .searchBlock").removeClass("active");
					$(e.currentTarget).addClass("active");
					focus(results[$(e.currentTarget).attr("data-inx")]);
				}
			});
		}
		
		if(excs.length == 0)
			$("#searchButtonsDown").hide();
		else{			
			$("#showMoreBtn").attr("data-text",text);
			$("#showMoreBtn").attr("data-excs",excs.join(","));
			$("#searchButtonsDown").css("display","flex");			
		}
		$("#searchResults .searchBlock:first-child").trigger("click");
		
			
	}).fail(function(err,textstatus){
		showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
	});
	if($("#searchResultsWrapper").css("display") == "none"){
		$("#searchResultsWrapper").css("display","flex");
		$("#searchResultsWrapper").css("left",`-${$("#searchResultsWrapper").outerWidth()}px`)
		$("#searchResultsWrapper").stop(true,true);
		$( "#searchResultsWrapper" ).animate({
			left: "+="+$("#searchResultsWrapper").outerWidth(),
		  }, 500);
	}
}

$(window).on("load",function(){
	searchBlockPrefab = $("#searchResults .searchBlock:first-child").clone();	
	$("#searchResults").html("");
	routeItemPrefab = $("#routeList .routeItem:first-child").clone();
	$("#routeList").html("");
	instructionPrefab = $("#instructionList .instructionItem:first-child").clone();
	$("#instructionList").html("");
	
	map = L.map('map',{
		
		zoomControl: false
	}).setView([48.566479, 39.311960], 12);
	
	L.tileLayer(tilePattern, {
		maxZoom: 18,
		id: 'osm'
	}).addTo(map);

	  L.control.zoom({position: 'topright'}).addTo(map);
	  
	  $("#searchInput").on("keypress",function(e){
		  if(e.key == "Enter"){
			  search($("#searchInput").val().trim());
			  $("#searchInput").val("");
		  }
	  });
	  $("#searchBtn").on("click",function(e){
			search($("#searchInput").val().trim());
			$("#searchInput").val("");
	  });
	  $(window).on("mousedown",function(e){	
		mouseDownX = e.clientX;
		mouseDownY = e.clientY;
	  });
	  $(window).on("click",function(e){	
				$("#contextMenu").hide();
	  });
	  $("#contextMenu li:first-child").on("click",function(){
		 copyTextToClipboard($("#contextMenu li:first-child").attr("data-coord"));
		 showMsg("Координаты скопированы!",1000);		 
	  });
	  
	  //Что здесь?
	  $("#contextMenu li").eq(1).on("click",function(){		  		 
		 let lat = $("#contextMenu li:first-child").attr("data-coord").split(",")[0];
		 let lon= $("#contextMenu li:first-child").attr("data-coord").split(",")[1];
			$.ajax({
			  url: `${nominatimReverse}&lat=${lat}&lon=${lon}`
			}).done(function(data) {
				if(typeof(data) != "object"){
					showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
					return;
				}
				results = [data];
				if(lastObj != null)
					lastObj.removeFrom(map);
				$("#searchResults").html("");
				$(".searchCounter").html("Найдено результатов: "+1);							
				let el = $(searchBlockPrefab).clone();
				$(el).attr("data-inx",0);
				$(el).find(".sName").html(data.display_name);
				$(el).find("img").attr("src",data.icon);
				$(el).find("a").attr("href",`${nominatimDetails}?osmtype=${data.osm_type[0].toUpperCase()}&osmid=${data.osm_id}&class=${data.class?data.class:""}`);					
				$("#searchResults").append(el);
				$(el).on("click",function(e){
					if(!$(e.target).is(".linkDetail")){
						$("#searchResults .searchBlock").removeClass("active");
						$(e.currentTarget).addClass("active");
						focus(results[$(e.currentTarget).attr("data-inx")]);
					}
				});
				
					$("#searchButtonsDown").hide();
					
				$("#searchResults .searchBlock:first-child").trigger("click");
				
				
				if($("#searchResultsWrapper").css("display") == "none"){
					$("#searchResultsWrapper").css("display","flex");
					$("#searchResultsWrapper").css("left",`-${$("#searchResultsWrapper").outerWidth()}px`)
					$("#searchResultsWrapper").stop(true,true);
					$( "#searchResultsWrapper" ).animate({
						left: "+="+$("#searchResultsWrapper").outerWidth(),
					  }, 500);
				}
		
			
	}).fail(function(err,textstatus){
		showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
	});
	});
	  //Проложить маршрут отсюда
	  $("#contextMenu li").eq(2).on("click",function(){
			if($("#routeResultsWrapper").css("display") == "none")
				$("#openRouters").trigger("click");
		 let lat = $("#contextMenu li:first-child").attr("data-coord").split(",")[0];
		 let lon= $("#contextMenu li:first-child").attr("data-coord").split(",")[1];
			$.ajax({
			  url: `${nominatimReverse}&lat=${lat}&lon=${lon}`
			}).done(function(data) {
				if(typeof(data) != "object"){
					showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
					return;
				}
				
				$("#routeFromField").val(data.display_name);
				$("#routeFromField").attr("data-lon",lon);
				$("#routeFromField").attr("data-lat",lat);
				
				if(fromMarker != null)
					fromMarker.removeFrom(map);
				fromMarker = L.marker([lat, lon]).bindPopup(function (layer) {
					return data.display_name;
				}).addTo(map);
				fromMarker._icon.classList.add("greenMarker");
				updateRoutes();
			
		}).fail(function(err,textstatus){
			showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
		});
		});
	  //Проложить маршрут сюда
	  $("#contextMenu li").eq(3).on("click",function(){
			if($("#routeResultsWrapper").css("display") == "none")
				$("#openRouters").trigger("click");
		 let lat = $("#contextMenu li:first-child").attr("data-coord").split(",")[0];
		 let lon= $("#contextMenu li:first-child").attr("data-coord").split(",")[1];
			$.ajax({
			  url: `${nominatimReverse}&lat=${lat}&lon=${lon}`
			}).done(function(data) {
				if(typeof(data) != "object"){
					showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
					return;
				}
				
				$("#routeToField").val(data.display_name);
				$("#routeToField").attr("data-lon",lon);
				$("#routeToField").attr("data-lat",lat);
				
				if(toMarker != null)
					toMarker.removeFrom(map);
				toMarker= L.marker([lat, lon]).bindPopup(function (layer) {
					return data.display_name;
				}).addTo(map);
				toMarker._icon.classList.add("redMarker");
				updateRoutes();
			
		}).fail(function(err,textstatus){
			showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
		});
	});
	$("#showMoreBtn").on("click",function(){
		search($("#showMoreBtn").attr("data-text"),$("#showMoreBtn").attr("data-excs"));
	});
	  $(window).on("contextmenu",function(e){		  
			 if(e.button == 2 && e.target == $("#map").get(0)){				 
				let pointXY = L.point(e.offsetX, e.offsetY);
				let pointlatlng = map.containerPointToLatLng(pointXY);
				$("#contextMenu li:first-child").attr("data-coord",pointlatlng.lat+","+pointlatlng.lng);
				//L.marker([pointlatlng.lat, pointlatlng.lng]).addTo(map);
				
				let lat = pointlatlng.lat.toString();
				let lng = pointlatlng.lng.toString();
				lat = lat.split(".")[0]+"."+lat.split(".")[1].substring(0,5);
				lng = lng.split(".")[0]+"."+lng.split(".")[1].substring(0,5);
				$("#contextMenu li:first-child").html(lat+", "+lng);
				
				
				$("#contextMenu").css({
					"left":e.clientX+"px",
					"top":e.clientY+"px"
				});
				$("#contextMenu").show();
				 e.cancelBubble = true;
				 e.preventDefault();
				 return false;
			 }
			 else
				$("#contextMenu").hide();
		});
		
	  $("#searchCloser").on("click",function(){
			$("#searchResultsWrapper").stop(true,true);
			$( "#searchResultsWrapper" ).animate({
				left: "-="+$("#searchResultsWrapper").outerWidth(),
			  }, 500,function(){				  
				if(lastObj != null)
					lastObj.removeFrom(map);
				$("#searchResults").html("");
				$("#searchResultsWrapper").hide();	  
			});
	  });
	  $(window).on("keyup",function(e){
		 if($(e.target).attr("id") == "routeFromField" && e.key == "Enter")
				$("#searchBtnFrom").trigger("click");
		 if($(e.target).attr("id") == "routeToField" && e.key == "Enter")
				$("#searchBtnTo").trigger("click");
	  });
	  
	  $("#searchBtnFrom").on("click",function(){
		  let text = $("#routeFromField").val();
		  $.ajax({
				  url: nominatimSearch+text+"&limit=1"
				}).done(function(data) {
					if(typeof(data) != "object"){
						showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
						return;
					}
					if(data.length == 0){
						showMsg("Ничего не найдено!",2000)
						return;
					}			
					data = data[0];
					$("#routeFromField").val(data.display_name);
					$("#routeFromField").attr("data-lon",data.lon);
					$("#routeFromField").attr("data-lat",data.lat);
					
					if(fromMarker != null)
						fromMarker.removeFrom(map);
					fromMarker = L.marker([data.lat, data.lon]).bindPopup(function (layer) {
						return data.display_name;
					}).addTo(map);
				fromMarker._icon.classList.add("greenMarker");
					
					updateRoutes();					
					map.setView(fromMarker.getLatLng(),14);
						
				}).fail(function(err,textstatus){
					showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
				});
		  
	  });
	  
	  $("#searchBtnTo").on("click",function(){
		  let text = $("#routeToField").val();
		  $.ajax({
				  url: nominatimSearch+text+"&limit=1"
				}).done(function(data) {
					if(typeof(data) != "object"){
						showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
						return;
					}
					if(data.length == 0){
						showMsg("Ничего не найдено!",2000)
						return;
					}			
					data = data[0];
					$("#routeToField").val(data.display_name);
					$("#routeToField").attr("data-lon",data.lon);
					$("#routeToField").attr("data-lat",data.lat);
					
					if(toMarker!= null)
						toMarker.removeFrom(map);
					toMarker = L.marker([data.lat, data.lon]).bindPopup(function (layer) {
						return data.display_name;
					}).addTo(map);
					toMarker._icon.classList.add("redMarker");
					
					updateRoutes();			
					map.setView(toMarker.getLatLng(),14);
						
				}).fail(function(err,textstatus){
					showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
				});
		  
	  });
	  
	  $("#routerCloser").on("click",function(){
			
			$("#routeResultsWrapper").stop(true,true);
			$( "#routeResultsWrapper" ).animate({
				right: "-="+$("#routeResultsWrapper").outerWidth(),
			  }, 500,function(){				  
				if(fromMarker != null)
					fromMarker.removeFrom(map);  
				if(toMarker!= null)
					toMarker.removeFrom(map);
				clearMapRoutes();
				routes = [];
				seletedRouteInx = null;
				
				$("#routeList").html("");
				$("#routeFromField").val("");
				$("#routeFromField").removeAttr("data-lat");
				$("#routeFromField").removeAttr("data-lon");
				
				$("#routeToField").val("");
				$("#routeToField").removeAttr("data-lat");
				$("#routeToField").removeAttr("data-lon");
				
				$("#routeResultsWrapper").hide();	
				
				updateInstructions();
			});
	  });
	  $("#openRouters").on("click",function(){		   
			if($("#routeResultsWrapper").css("display") == "none"){
				$("#routeResultsWrapper").css("display","flex");
				$("#routeResultsWrapper").stop(true,true);
				$("#routeResultsWrapper").css("right",`-${$("#routeResultsWrapper").outerWidth()}px`)
				$( "#routeResultsWrapper" ).animate({
					right: "+="+$("#routeResultsWrapper").outerWidth(),
				  }, 500);
			}
	  });
	  
		
	  });
	  

let msgTimeout;
function showMsg(text,delay = 1000){
	clearTimeout(msgTimeout);
	$("#msg").show();
	$("#msg").stop(true,true);
	$("#msg").html(text);
	$("#msg").css("top",`-${$("#msg").outerHeight()}px`)
	$( "#msg" ).animate({
		top: "+="+$("#msg").outerHeight(),
	  }, 300,function(){
		  msgTimeout = setTimeout(function(){
				$( "#msg" ).animate({
				top: "-="+$("#msg").outerHeight(),
			  }, 300,function(){
				  $("#msg").hide();
			  })
		  },delay)
	});
}	  
function getDist(x1,y1,x2,y2){
	return Math.Hypot(x2 - x1, y2 - y1);
}


function fallbackCopyTextToClipboard(text) {
  var textArea = document.createElement("textarea");
  textArea.value = text;
  
  
  textArea.style.top = "0";
  textArea.style.left = "0";
  textArea.style.position = "fixed";

  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();

  try {
    var successful = document.execCommand('copy');
    var msg = successful ? 'successful' : 'unsuccessful';
    console.log('Fallback: Copying text command was ' + msg);
  } catch (err) {
    console.error('Fallback: Oops, unable to copy', err);
  }

  document.body.removeChild(textArea);
}
function copyTextToClipboard(text) {
  if (!navigator.clipboard) {
    fallbackCopyTextToClipboard(text);
    return;
  }
  navigator.clipboard.writeText(text).then(function() {
  }, function(err) {
    console.error('Async: Could not copy text: ', err);
  });
}


function updateRoutes(){
		
		let lat1 = $("#routeFromField").attr("data-lat");
		let lon1 = $("#routeFromField").attr("data-lon");
		
		let lat2 = $("#routeToField").attr("data-lat");
		let lon2 = $("#routeToField").attr("data-lon");
		
	
		if(!lat1 || !lon1 || !lat2 || !lon2)
			return;
			$.ajax({
			  url: `${routeApi}/route/v1/driving/${lon1},${lat1};${lon2},${lat2}?alternatives=true&steps=true&geometries=geojson&overview=full&annotations=true`
			}).done(function(data) {
				if(typeof(data) != "object"){
					showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
					return;
				}
				if(data.code != 'Ok'){					
					showMsg("Возникла ошибка запроса!<br>Сервер вернул код "+data.code,3000);
					console.log(data);
					return;
				}				
				
				
				routes = data.routes;
				
				clearMapRoutes()				
				$("#routeList").html("");
				
				
				for(let i =0; i< data.routes.length;i++){
					let el = $(routeItemPrefab).clone();
					$(el).find(".routeName").html("через "+data.routes[i].legs[0].summary);
					$(el).find(".routeDuration").html(prettyTime(data.routes[i].duration));
					$(el).find(".routeDist").html(prettyDist(data.routes[i].distance));
					$(el).attr("data-index",i);
					$("#routeList").append(el);
					
					$(el).on("click",function(e){
						selectRoute($(e.currentTarget).attr("data-index"));
					});
				}			
				selectRoute(0);
			
		}).fail(function(err,textstatus){
			showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
		});
	
}


function selectRoute(n){
		clearMapRoutes();
		for(let i = 0; i < routes.length;i++){
			if(i != n){
				let oo = L.geoJSON(routes[i].geometry, {
				style: function (feature) {
					return {color: "#7e7e7e"};
				}
				}).addTo(map);
				routeMapObjects.push(oo);
				let inx = i;
				oo.on("click",function(e){
					selectRoute(inx);
				});		
			}	
		}		
		let cur = L.geoJSON(routes[n].geometry, {
			style: function (feature) {
				return {color: "#a80bff"};
			}
		}).addTo(map);
		routeMapObjects.push(cur);
		$("#routeList .routeItem").removeClass("active");
		$("#routeList .routeItem").each((i,el)=>{
			if($(el).attr("data-index") == n)
				$(el).addClass("active");
		});
		
		seletedRouteInx = n;
		map.fitBounds(cur.getBounds());
		updateInstructions();
}


function selectInstruction(n){
	
	if(instructionObj!= null)
		instructionObj.removeFrom(map);
	$("#instructionList .instructionItem").removeClass("active");
	if(!instructions[n])return;
	
	
	$("#instructionList .instructionItem").each((ii,el)=>{
		if(ii == n)
			$(el).addClass("active")
	});
	
	
	instructionObj = L.geoJSON(instructions[n].geometry, {
		style: function (feature) {
			return {color: "#0000FF",weight: '10'};
		}
	}).addTo(map);	
	
	map.fitBounds(instructionObj.getBounds());
	
}
function updateVisualInstructions(){
		$("#instructionList").html("");
		for(let i = 0; i < instructions.length;i++){
			let el = $(instructionPrefab).clone();
			$(el).attr("data-inx",i);
			$(el).find(".instructionName").html(instructions[i].name);
			$(el).find(".instructionInx").html(instructions[i].index);
			$(el).find(".instructionInfo").html(prettyDist(instructions[i].distance));			
			$("#instructionList").append(el);			
			$(el).on("click",function(e){
				selectInstruction($(e.currentTarget).attr("data-inx"));
			});
		}
}
function updateInstructions(){
	if(instructionObj!= null)
		instructionObj.removeFrom(map);
		$("#instructionList").html("");
		instructions = [];
		if(seletedRouteInx == null)
			return;
		let routeCur = routes[seletedRouteInx];
			$.ajax({
			  url: instructionServer,	  
			  type:"POST",
			  contentType: "application/json; charset=utf-8",
			  data:JSON.stringify(routeCur.legs)
			}).done(function(data) {				
					let inx = 1;					
					let result = [];
					for(let leg in routeCur.legs){
						for(let stepInx in routeCur.legs[leg].steps){
							let step  =routeCur.legs[leg].steps[stepInx];
							let name = "Движение по "+step.name;
							if (data.length >= inx)
								step.name = data[inx-1];
							step.index = inx++;
							result.push(step);
						}
					}
					instructions = result;
					updateVisualInstructions();
				
			}).fail(function(err,textstatus){
				showMsg("Возникла ошибка обращения к серверу инструкций маршрута!<br>"+textstatus,4000);
			});
}
function clearMapRoutes(){
	for(let i = 0; i < routeMapObjects.length;i++)
		routeMapObjects[i].removeFrom(map);
	routeMapObjects = [];
}
function prettyTime(timeSec){
	if(timeSec < 60)
		return Math.round(timeSec)+" сек";
	
	let hour = Math.floor(timeSec/3600);
	let min= Math.floor(timeSec%3600/60);
	if(hour ==0)
		return min + " мин";
	return hour+" ч "+ min+ " мин";
}
function prettyDist(distMetr){
	distMetr = Math.round(distMetr);
	if(distMetr > 1000)
		return (distMetr/1000).toFixed(1) + " км";
	else
		return distMetr + " м";
}