<?PHP

ini_set('dsipay_errors',1);
ini_set('dsipay_startup_errors',1);
ini_set('memory_limit','2048M');
error_reporting(E_ERROR | E_WARNING);

$DB_HOST = "localhost";
$DB_NAME = "gis";
$DB_USER = "postgreadmin";
$DB_PWD = "lbgfgths";
