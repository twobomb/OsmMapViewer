var map, mouseDownX =0,mouseDownY = 0;

let nominatimSearch ="https://nominatim.openstreetmap.org/search?polygon_geojson=1&accept-language=ru&format=json&q=";
let nominatimReverse="https://nominatim.openstreetmap.org/reverse?polygon_geojson=1&accept-language=ru&format=json";
let nominatimDetails="https://nominatim.openstreetmap.org/ui/details.html";
let tilePattern = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
let searchBlockPrefab;
let results = [];
let lastObj = null;

function focus(el){
	if(lastObj != null)
		lastObj.removeFrom(map);
	
	lastObj = L.geoJSON(el.geojson, {
    style: function (feature) {
        return {color: "#0000FF"};
    }
	}).bindPopup(function (layer) {
		return el.display_name;
	}).addTo(map);
	
	
	map.fitBounds(lastObj.getBounds());
}
function search(text,excluded = ""){
	if(text == ""){
		showMsg("Введите текст для поиска!");
		return;
	}
	
	let url = nominatimSearch+text;
	if(excluded !="")
		url+="&exclude_place_ids="+excluded;
	$.ajax({
	  url: url
	}).done(function(data) {
		if(typeof(data) != "object"){
			showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
			return;
		}
		if(data.length == 0){
			showMsg("Ничего не найдено!",2000)
			return;
		}
		results = data;
		if(lastObj != null)
			lastObj.removeFrom(map);
		$("#searchResults").html("");
		$(".searchCounter").html("Найдено результатов: "+data.length);
		let excs = excluded.split(",");
		for(let i = 0 ;i < data.length;i++){			
			excs.push(data[i].place_id);
			let el = $(searchBlockPrefab).clone();
			$(el).attr("data-inx",i);
			$(el).find(".sName").html(data[i].display_name);
			$(el).find("img").attr("src",data[i].icon);
			$(el).find("a").attr("href",`${nominatimDetails}?osmtype=${data[i].osm_type[0].toUpperCase()}&osmid=${data[i].osm_id}&class=${data.class?data.class:""}`);					
			$("#searchResults").append(el);
			$(el).on("click",function(e){
				if(!$(e.target).is(".linkDetail")){
					$("#searchResults .searchBlock").removeClass("active");
					$(e.currentTarget).addClass("active");
					focus(results[$(e.currentTarget).attr("data-inx")]);
				}
			});
		}
		
		if(excs.length == 0)
			$("#searchButtonsDown").hide();
		else{			
			$("#showMoreBtn").attr("data-text",text);
			$("#showMoreBtn").attr("data-excs",excs.join(","));
			$("#searchButtonsDown").css("display","flex");			
		}
		$("#searchResults .searchBlock:first-child").trigger("click");
		
			
	}).fail(function(err,textstatus){
		showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
	});
	if($("#searchResultsWrapper").css("display") == "none"){
		$("#searchResultsWrapper").css("display","flex");
		$("#searchResultsWrapper").css("left",`-${$("#searchResultsWrapper").outerWidth()}px`)
		$("#searchResultsWrapper").stop(true,true);
		$( "#searchResultsWrapper" ).animate({
			left: "+="+$("#searchResultsWrapper").outerWidth(),
		  }, 500);
	}
}
$(window).on("load",function(){
	searchBlockPrefab = $("#searchResults .searchBlock:first-child").clone();
	$("#searchResults").html("");
	map = L.map('map',{
		
		zoomControl: false
	}).setView([48.566479, 39.311960], 12);
	
	L.tileLayer(tilePattern, {
		maxZoom: 18,
		id: 'osm'
	}).addTo(map);

	  L.control.zoom({position: 'topright'}).addTo(map);
	  
	  $("#searchInput").on("keypress",function(e){
		  if(e.key == "Enter"){
			  search($("#searchInput").val().trim());
			  $("#searchInput").val("");
		  }
	  });
	  $("#searchBtn").on("click",function(e){
			search($("#searchInput").val().trim());
			$("#searchInput").val("");
	  });
	  $(window).on("mousedown",function(e){	
		mouseDownX = e.clientX;
		mouseDownY = e.clientY;
	  });
	  $(window).on("click",function(e){	
				$("#contextMenu").hide();
	  });
	  $("#contextMenu li:first-child").on("click",function(){
		 copyTextToClipboard($("#contextMenu li:first-child").attr("data-coord"));
		 showMsg("Координаты скопированы!",1000);		 
	  });
	  $("#contextMenu li").eq(1).on("click",function(){		  
		 let lat = $("#contextMenu li:first-child").attr("data-coord").split(",")[0];
		 let lon= $("#contextMenu li:first-child").attr("data-coord").split(",")[1];
			$.ajax({
			  url: `${nominatimReverse}&lat=${lat}&lon=${lon}`
			}).done(function(data) {
				if(typeof(data) != "object"){
					showMsg("Возникла ошибка запроса!<br>Сервер вернул не верные данные",3000);
					return;
				}
				results = [data];
				if(lastObj != null)
					lastObj.removeFrom(map);
				$("#searchResults").html("");
				$(".searchCounter").html("Найдено результатов: "+1);							
				let el = $(searchBlockPrefab).clone();
				$(el).attr("data-inx",0);
				$(el).find(".sName").html(data.display_name);
				$(el).find("img").attr("src",data.icon);
				$(el).find("a").attr("href",`${nominatimDetails}?osmtype=${data.osm_type[0].toUpperCase()}&osmid=${data.osm_id}&class=${data.class?data.class:""}`);					
				$("#searchResults").append(el);
				$(el).on("click",function(e){
					if(!$(e.target).is(".linkDetail")){
						$("#searchResults .searchBlock").removeClass("active");
						$(e.currentTarget).addClass("active");
						focus(results[$(e.currentTarget).attr("data-inx")]);
					}
				});
				
					$("#searchButtonsDown").hide();
					
				$("#searchResults .searchBlock:first-child").trigger("click");
				
				
				if($("#searchResultsWrapper").css("display") == "none"){
					$("#searchResultsWrapper").css("display","flex");
					$("#searchResultsWrapper").css("left",`-${$("#searchResultsWrapper").outerWidth()}px`)
					$("#searchResultsWrapper").stop(true,true);
					$( "#searchResultsWrapper" ).animate({
						left: "+="+$("#searchResultsWrapper").outerWidth(),
					  }, 500);
				}
		
			
	}).fail(function(err,textstatus){
		showMsg("Возникла ошибка запроса!<br>"+textstatus,4000);
	});
		 
		 
	  });
	$("#showMoreBtn").on("click",function(){
		search($("#showMoreBtn").attr("data-text"),$("#showMoreBtn").attr("data-excs"));
	});
	  $(window).on("contextmenu",function(e){		  
			 if(e.button == 2 && e.target == $("#map").get(0)){				 
				let pointXY = L.point(e.offsetX, e.offsetY);
				let pointlatlng = map.containerPointToLatLng(pointXY);
				$("#contextMenu li:first-child").attr("data-coord",pointlatlng.lat+","+pointlatlng.lng);
				//L.marker([pointlatlng.lat, pointlatlng.lng]).addTo(map);
				
				let lat = pointlatlng.lat.toString();
				let lng = pointlatlng.lng.toString();
				lat = lat.split(".")[0]+"."+lat.split(".")[1].substring(0,5);
				lng = lng.split(".")[0]+"."+lng.split(".")[1].substring(0,5);
				$("#contextMenu li:first-child").html(lat+", "+lng);
				
				
				$("#contextMenu").css({
					"left":e.clientX+"px",
					"top":e.clientY+"px"
				});
				$("#contextMenu").show();
				 e.cancelBubble = true;
				 e.preventDefault();
				 return false;
			 }
			 else
				$("#contextMenu").hide();
		});
		
	  $("#searchCloser").on("click",function(){
			$("#searchResultsWrapper").stop(true,true);
			$( "#searchResultsWrapper" ).animate({
				left: "-="+$("#searchResultsWrapper").outerWidth(),
			  }, 500,function(){				  
				if(lastObj != null)
					lastObj.removeFrom(map);
				$("#searchResults").html("");
				$("#searchResultsWrapper").hide();	  
			});
	  });
	  
		
	  });
	  

let msgTimeout;
function showMsg(text,delay = 1000){
	clearTimeout(msgTimeout);
	$("#msg").show();
	$("#msg").stop(true,true);
	$("#msg").html(text);
	$("#msg").css("top",`-${$("#msg").outerHeight()}px`)
	$( "#msg" ).animate({
		top: "+="+$("#msg").outerHeight(),
	  }, 300,function(){
		  msgTimeout = setTimeout(function(){
				$( "#msg" ).animate({
				top: "-="+$("#msg").outerHeight(),
			  }, 300,function(){
				  $("#msg").hide();
			  })
		  },delay)
	});
}	  
function getDist(x1,y1,x2,y2){
	return Math.Hypot(x2 - x1, y2 - y1);
}


function fallbackCopyTextToClipboard(text) {
  var textArea = document.createElement("textarea");
  textArea.value = text;
  
  
  textArea.style.top = "0";
  textArea.style.left = "0";
  textArea.style.position = "fixed";

  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();

  try {
    var successful = document.execCommand('copy');
    var msg = successful ? 'successful' : 'unsuccessful';
    console.log('Fallback: Copying text command was ' + msg);
  } catch (err) {
    console.error('Fallback: Oops, unable to copy', err);
  }

  document.body.removeChild(textArea);
}
function copyTextToClipboard(text) {
  if (!navigator.clipboard) {
    fallbackCopyTextToClipboard(text);
    return;
  }
  navigator.clipboard.writeText(text).then(function() {
  }, function(err) {
    console.error('Async: Could not copy text: ', err);
  });
}